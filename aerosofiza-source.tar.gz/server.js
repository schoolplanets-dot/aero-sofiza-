#!/usr/bin/env node
/* Аэро-СофИзА · сервер веб-приложения.
   • раздаёт public/ (index.html — исходная программа + модуль ОТО + геокарта; PWA);
   • /api/v1/*  — REST API ядра ОТО (тот же код ядра, что встроен в index.html; извлекается по маркерам разделов);
   • имитатор внешних систем и инженеров работает на сервере (общая картина для всех подключённых устройств);
   • /ws/chat   — онлайн-чат исходной программы (комнаты, история);
   • /ws/gps    — обмен GPS-позициями между устройствами (геокарта исходной программы);
   • /api/track — приём координат от трекера/телефона (OsmAnd, Traccar Client, GPSLogger: GET/POST id,lat,lon).
   Запуск: npm install && npm start   (переменные: PORT, SCALE, SIM, TRACK_KEY, DATABASE_URL, DATA_DIR) */
'use strict';
const fs = require('fs'), path = require('path'), http = require('http'), vm = require('vm'), url = require('url');
const { WebSocketServer } = require('ws');
const { openStore, adapterFor } = require('./storage');

const PORT = +process.env.PORT || 3000;
const SCALE = +process.env.SCALE || 1;                 // 1 = реальное время (для работы по GPS)
const SIM = process.env.SIM !== '0';                   // серверный имитатор
const TRACK_KEY = process.env.TRACK_KEY || '';         // ключ для /api/track (пусто — без ключа)
const PUB = path.join(__dirname, 'public');
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');

(async function main() {
// ---------- постоянное хранилище (база данных; без DATABASE_URL — файлы в DATA_DIR) ----------
const store = await openStore({ dataDir: DATA, keys: ['oto-store', 'chat-history'] });
console.log('[хранилище]', store.kind);

// ---------- ядро ОТО из index.html ----------
const html = fs.readFileSync(path.join(PUB, 'index.html'), 'utf8');
const A = html.indexOf('globalThis.OTO = globalThis.OTO || {}; OTO.PACKS'), B = html.indexOf('/* ===== src/client/map.js ===== */');
if (A < 0 || B < 0) throw new Error('Не найдены маркеры ядра ОТО в index.html');
global.require = require;
vm.runInThisContext(html.slice(A, B), { filename: 'oto-core.js' });
const OTO = global.OTO;
const S = new OTO.DispatchServer({ packs: OTO.PACKS, defaultPackId: OTO.DEFAULT_PACK || 'VDNH-GEO', adapter: adapterFor(store, 'oto-store'), scale: SCALE });
const pack = () => S.d.location.pack;
console.log(`[ОТО] пакет «${pack().name}» (${pack().nodes.length} узлов, ${pack().edges.length} рёбер), ускорение ×${S.clock.scale ? S.clock.scale() : SCALE}`);
setInterval(() => { try { S.tick(); } catch (e) { console.error('tick', e); } }, 1000);

let sim = null, simBusy = false;
if (SIM) {
  sim = new OTO.Simulator(new OTO.ApiClient(new OTO.EmbeddedTransport(S)).as('sim'));
  sim.init().then(() => { sim.start(); console.log('[ОТО] имитатор запущен на сервере'); }).catch(e => console.error('sim init', e));
  setInterval(async () => { if (simBusy || !sim.S.ready || !sim.isRunning()) return; simBusy = true; try { await sim.step(); } catch (e) { console.warn('sim', e.message); } finally { simBusy = false; } }, 1000);
}
const api = (method, p, body, headers, query) => OTO.Api.handle(S, { method, path: '/api/v1' + p, query: query || {}, body, headers: headers || {} });

// ---------- HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8', '.geojson': 'application/geo+json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8' };
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS' };
const send = (res, status, obj, extra) => { const b = JSON.stringify(obj); res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, CORS, extra || {})); res.end(b); };
const readBody = req => new Promise((ok, fail) => { let n = 0; const ch = []; req.on('data', c => { n += c.length; if (n > 8e6) { fail(new Error('слишком большой запрос')); req.destroy(); } else ch.push(c); }); req.on('end', () => ok(Buffer.concat(ch).toString('utf8'))); req.on('error', fail); });
const INJECT = '<head>\n  <script>window.OTO_API_URL = location.origin; /* сервер приложения: REST API ядра ОТО */</script>';
const indexHtml = () => fs.readFileSync(path.join(PUB, 'index.html'), 'utf8').replace('<head>', INJECT);

async function handleApi(req, res, u) {
  let body; if (!['GET', 'HEAD', 'DELETE'].includes(req.method)) { const t = await readBody(req); if (t) { try { body = JSON.parse(t); } catch (e) { return send(res, 400, { error: { code: 'BAD_JSON', message: 'Тело запроса — не JSON' } }); } } }
  const headers = {}; for (const [k, v] of Object.entries(req.headers)) headers[k.toLowerCase()] = v;
  const p = u.pathname.replace(/^\/api\/v1/, '') || '/';
  const r = api(req.method, p, body, headers, Object.fromEntries(new URLSearchParams(u.search || '')));
  if (r.raw) {
    const raw = r.raw, data = raw.bytes ? Buffer.from(raw.bytes) : Buffer.from(raw.text || '', 'utf8');
    res.writeHead(r.status, Object.assign({ 'Content-Type': raw.contentType || 'application/octet-stream', 'Content-Disposition': `attachment; filename="${encodeURIComponent(raw.filename || 'download')}"` }, CORS)); return res.end(data);
  }
  if (sim && req.method !== 'GET' && r.status < 300 && /^\/(config\/location|admin\/reset)/.test(p)) sim.reset().then(() => sim.start()).catch(e => console.warn('sim reset', e.message));
  send(res, r.status, r.body === undefined ? null : r.body);
}
// трекер: /api/track?id=vehicle-03&lat=..&lon=..&accuracy=..&speed=..&bearing=..&key=..  (OsmAnd: {lat},{lon}; Traccar: id/lat/lon)
async function handleTrack(req, res, u) {
  const q = Object.fromEntries(new URLSearchParams(u.search || ''));
  if (req.method === 'POST') { const t = await readBody(req); try { Object.assign(q, JSON.parse(t)); } catch (e) { Object.assign(q, Object.fromEntries(new URLSearchParams(t))); } }
  if (TRACK_KEY && q.key !== TRACK_KEY) return send(res, 403, { error: { code: 'FORBIDDEN', message: 'Неверный ключ трекера' } });
  const id = q.id || q.deviceid, lat = +q.lat, lon = +(q.lon || q.lng);
  if (!id || !isFinite(lat) || !isFinite(lon)) return send(res, 422, { error: { code: 'VALIDATION', message: 'Нужны id, lat, lon' } });
  const b = { lat, lon, source: 'tracker' };
  if (q.accuracy || q.acc) b.accuracy = +(q.accuracy || q.acc); if (q.speed) b.speedMs = Math.max(0, Math.min(80, +q.speed)); if (q.bearing || q.heading) b.heading = (+(q.bearing || q.heading) + 360) % 360;
  try {
    const out = S.d.agents[id] ? S.ingestAgentPosition('svc-tracker', id, b) : S.ingestVehiclePosition('svc-tracker', id, b);
    gpsBroadcast({ type: 'gps', client: 'tracker:' + id, id, name: (S.d.vehicles[id] || S.d.agents[id] || {}).name || id, lat, lon, acc: b.accuracy || 0, ts: Date.now() });
    send(res, 200, out);
  } catch (e) { send(res, e.status || 500, { error: { code: e.code || 'ERROR', message: e.message, details: e.details || null } }); }
}
function serveStatic(req, res, u) {
  let p = decodeURIComponent(u.pathname); if (p === '/' || p === '/index.html') { res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache' }); return res.end(indexHtml()); }
  const f = path.normalize(path.join(PUB, p)); if (!f.startsWith(PUB)) { res.writeHead(403); return res.end(); }
  fs.stat(f, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Не найдено'); }
    const ext = path.extname(f).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.js' && p === '/sw.js' || ext === '.geojson' ? 'no-cache' : 'public, max-age=3600', 'Content-Length': st.size });
    fs.createReadStream(f).pipe(res);
  });
}
const server = http.createServer(async (req, res) => {
  const u = url.parse(req.url);
  try {
    if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
    if (u.pathname.startsWith('/api/v1')) return await handleApi(req, res, u);
    if (u.pathname === '/api/track') return await handleTrack(req, res, u);
    if (u.pathname === '/healthz') return send(res, 200, { ok: true, storage: store.kind.split(':')[0], pack: pack().id, clients: { chat: chatWss.clients.size, gps: gpsWss.clients.size } });
    return serveStatic(req, res, u);
  } catch (e) { console.error(e); send(res, 500, { error: { code: 'SERVER', message: e.message } }); }
});

// ---------- WebSocket: чат и GPS ----------
const chatWss = new WebSocketServer({ noServer: true, maxPayload: 256 * 1024 }), gpsWss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 });
const history = Object.assign({}, store.get('chat-history') || {});
let histT = null; const saveHist = () => { if (histT) return; histT = setTimeout(() => { histT = null; store.set('chat-history', history); }, 2000); };
chatWss.on('connection', ws => {
  ws.room = 'default';
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (m.type === 'join') { ws.room = String(m.room || 'default').slice(0, 80); (history[ws.room] || []).forEach(msg => ws.send(JSON.stringify({ type: 'chat', room: ws.room, message: msg }))); return; }
    if (m.type === 'chat' && m.message && m.message.id && m.message.text) {
      const room = String(m.room || ws.room).slice(0, 80); const h = history[room] = history[room] || []; if (!h.some(x => x.id === m.message.id)) { h.push(m.message); if (h.length > 200) h.splice(0, h.length - 200); saveHist(); }
      chatWss.clients.forEach(c => { if (c !== ws && c.readyState === 1 && c.room === room) c.send(JSON.stringify({ type: 'chat', room, message: m.message })); });
    }
  });
});
const lastGps = {};
function gpsBroadcast(m, except) { lastGps[m.client] = m; gpsWss.clients.forEach(c => { if (c !== except && c.readyState === 1) c.send(JSON.stringify(m)); }); }
gpsWss.on('connection', ws => {
  const now = Date.now(); ws.send(JSON.stringify({ type: 'snapshot', items: Object.values(lastGps).filter(x => now - x.ts < 120000) }));
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (m.type !== 'gps' || typeof m.lat !== 'number' || typeof m.lon !== 'number') return;
    const msg = { type: 'gps', client: String(m.client || '').slice(0, 40), id: String(m.id || '').slice(0, 40), name: String(m.name || '').slice(0, 80), lat: m.lat, lon: m.lon, acc: +m.acc || 0, ts: Date.now() };
    gpsBroadcast(msg, ws);
    // сотрудник, вошедший в исходной программе, — позиция передаётся и в диспетчеризацию ОТО (если в границах полигона)
    if (S.d.agents[msg.id]) { try { S.ingestAgentPosition('svc-gps-ws', msg.id, Object.assign({ lat: msg.lat, lon: msg.lon, source: 'device-gps' }, msg.acc ? { accuracy: msg.acc } : {})); } catch (e) { /* вне границ и т. п. — фиксируется в журнале ОТО */ } }
  });
});
server.on('upgrade', (req, sock, head) => {
  const p = url.parse(req.url).pathname;
  const w = p === '/ws/chat' ? chatWss : p === '/ws/gps' ? gpsWss : null; if (!w) return sock.destroy();
  w.handleUpgrade(req, sock, head, ws => w.emit('connection', ws, req));
});
server.listen(PORT, () => console.log(`[Аэро-СофИзА] http://localhost:${PORT}  (API: /api/v1, чат: /ws/chat, GPS: /ws/gps, трекер: /api/track)`));
let closing = false;
const bye = async () => { if (closing) return; closing = true; try { S.store.save(true); if (histT) store.set('chat-history', history); await store.close(); } catch (e) { /* */ } process.exit(0); };
process.on('SIGINT', bye); process.on('SIGTERM', bye);
})().catch(e => { console.error('[Аэро-СофИзА] запуск не удался:', e); process.exit(1); });
