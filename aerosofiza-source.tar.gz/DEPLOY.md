# Перенос Аэро-СофИзА на собственный сервер (без Manus)

Приложение не зависит от сервисов Manus. Это обычный Node.js-сервер (`server.js`) со статикой в `public/`. Карта Leaflet встроена в страницу, а тайлы подложки загружаются напрямую с OpenStreetMap и Esri. Вам понадобятся сервер, домен и одно из двух хранилищ данных:

| Хранилище | Когда выбирать | Как включить |
|---|---|---|
| **Файлы JSON** (по умолчанию) | один сервер, учебная нагрузка; проще всего | ничего не делать: данные лежат в `DATA_DIR` (в Docker — том `app-data`) |
| **MySQL / MariaDB / TiDB** | нужна отдельная база, резервное копирование средствами СУБД, внешний облачный MySQL | задать `DATABASE_URL=mysql://user:pass@host:3306/db` |

Приложение само создаёт таблицу `app_kv`. Ручная настройка схемы не нужна.

## 1. Что потребуется

Подойдёт VPS или собственный сервер с Linux (Ubuntu 22.04/24.04, Debian 12): 1 vCPU, 1 ГБ RAM, 5 ГБ диска. Также нужен домен или поддомен, например `oto.school338.ru`, с A-записью DNS на IP сервера. Откройте порты 80 и 443.

**HTTPS обязателен.** Без него браузеры на телефонах не выдают GPS. В обоих вариантах ниже сертификат Let's Encrypt выпускается бесплатно и автоматически.

## 2. Вариант А: Docker Compose (рекомендуется)

```bash
# 1) установить Docker (если ещё нет)
curl -fsSL https://get.docker.com | sudo sh

# 2) загрузить и распаковать проект
scp aerosofiza-selfhost.zip user@SERVER:~      # с вашего компьютера
ssh user@SERVER
unzip aerosofiza-selfhost.zip && cd aerosofiza

# 3) настроить
cp .env.example .env
nano .env            # укажите DOMAIN=ваш.домен и, желательно, TRACK_KEY

# 4) перенести текущие данные с сайта Manus (необязательно; выгрузка уже лежит в data-export/)
docker compose build app
docker compose run --rm -v "$PWD/data-export:/app/data-export:ro" app node scripts/import-data.js /app/data-export

# 5) запустить
docker compose up -d
docker compose logs -f app      # должно быть: [хранилище] file:/app/data
```

Откройте `https://ваш.домен`. Первый выпуск сертификата занимает до минуты.

**Хранение в MySQL внутри того же Compose.** В `.env` раскомментируйте `DATABASE_URL=mysql://aerosofiza:ПАРОЛЬ@db:3306/aerosofiza`, `MYSQL_PASSWORD` и `MYSQL_ROOT_PASSWORD`, заменив пароли. Затем запустите:

```bash
docker compose --profile mysql up -d db
# подождать ~20 с, пока база поднимется, затем импорт и запуск:
docker compose --profile mysql run --rm -v "$PWD/data-export:/app/data-export:ro" app node scripts/import-data.js /app/data-export
docker compose --profile mysql up -d
```

Внутри Docker-сети соединение с сервисом `db` идёт без TLS. Для внешней облачной базы TLS включается автоматически. Переменная `DB_SSL=0` отключает TLS, `DB_SSL=insecure` отключает проверку сертификата.

## 2а. Вариант без своего сервера: Amvera Cloud (ближе всего к публикации в Manus)

На Amvera не нужно настраивать сервер. Код загружается через Git или перетаскиванием в браузере, домен `https://имя.пользователь.amvera.io` с HTTPS выдаётся бесплатно, а папка `/data` сохраняется между перезапусками. В проекте уже есть `amvera.yml` и `deploy/Dockerfile.amvera`.

1. Зарегистрируйтесь на amvera.ru. На баланс начисляется стартовая сумма для теста. Создайте проект типа «Приложение» с тарифом не ниже «Начальный» (0,5 ГБ ОЗУ), потому что пробного тарифа на 0,1 ГБ приложению мало.
2. Во вкладке «Репозиторий» загрузите содержимое папки `aerosofiza` или выполните `git push amvera master` по инструкции на той же вкладке.
3. Чтобы перенести данные, загрузите файлы из `data-export/` во вкладке «Данные» (папка `/data`) до первого запуска.
4. Во вкладке «Переменные» задайте `TRACK_KEY` (и при желании `SCALE`, `SIM`). Нажмите «Собрать».
5. Во вкладке «Домены» добавьте бесплатный домен с HTTPS или подключите свой.

Проверка: `https://ваш-домен/healthz` должен вернуть `"storage":"file"`.

## 3. Вариант Б: без Docker (Node.js + systemd + nginx)

```bash
# Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs nginx certbot python3-certbot-nginx

# код и пользователь службы
sudo useradd --system --home /opt/aerosofiza aerosofiza
sudo mkdir -p /opt/aerosofiza && sudo unzip aerosofiza-selfhost.zip -d /tmp/ && sudo cp -r /tmp/aerosofiza/. /opt/aerosofiza/
cd /opt/aerosofiza && sudo npm ci --omit=dev
sudo cp .env.example .env && sudo nano .env      # SCALE, SIM, TRACK_KEY, при необходимости DATABASE_URL

# перенос данных (в файлы /var/lib/aerosofiza или в базу из DATABASE_URL)
sudo mkdir -p /var/lib/aerosofiza
sudo env DATA_DIR=/var/lib/aerosofiza $(grep -v '^#' .env | xargs) node scripts/import-data.js data-export
sudo chown -R aerosofiza: /var/lib/aerosofiza

# служба
sudo cp deploy/aerosofiza.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now aerosofiza
curl -s localhost:3000/healthz

# nginx + сертификат
sudo cp deploy/nginx.conf /etc/nginx/sites-available/aerosofiza
sudo sed -i 's/oto.example.ru/ваш.домен/' /etc/nginx/sites-available/aerosofiza
sudo ln -s /etc/nginx/sites-available/aerosofiza /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d ваш.домен
```

В `deploy/nginx.conf` уже есть заголовки `Upgrade`/`Connection` для WebSocket. Без них не работают чат (`/ws/chat`) и обмен GPS-позициями (`/ws/gps`).

## 4. Перенос данных

Файлы `data-export/oto-store.json` (заявки, журнал, параметры, позиции) и `chat-history.json` (если чат использовался) содержат выгрузку с сайта Manus на момент подготовки архива. Чтобы выгрузить свежие данные перед окончательным переключением, выполните в проекте Manus (или на любом компьютере с доступом к той базе):

```bash
DATABASE_URL='mysql://…' node scripts/export-data.js data-export
```

После этого повторите импорт (п. 2.4 или 3). **Импорт выполняйте при остановленном приложении:** иначе работающий сервер перезапишет данные своим состоянием из памяти.

Если перенос не нужен, пропустите импорт. Приложение стартует с чистого учебного состояния (пакет «Учебный полигон ВДНХ»).

## 5. Резервное копирование

Для файлового хранилища в Docker:
```bash
docker compose run --rm -v "$PWD/backup:/backup" app sh -c 'cp /app/data/*.json /backup/'
```
Без Docker архивируйте `/var/lib/aerosofiza`. Для MySQL используйте `mysqldump aerosofiza app_kv > backup.sql`. Универсальный способ для любого хранилища — `node scripts/export-data.js backup-ГГГГММДД`.

## 6. Обновление приложения

Замените файлы проекта, кроме `.env` и `data-export/`. Затем выполните `docker compose up -d --build`, а без Docker — `sudo npm ci --omit=dev && sudo systemctl restart aerosofiza`. Данные хранятся отдельно от кода и сохраняются.

## 7. Настройка после переноса

- **Трекеры** (OsmAnd, Traccar Client): `https://ваш.домен/api/track?id=vehicle-03&lat={0}&lon={1}&accuracy={3}&speed={5}&key=ВАШ_TRACK_KEY`.
- **Установка на телефон:** откройте сайт в Safari или Chrome и выберите «На экран Домой». Манифест и service worker приложение отдаёт само.
- **Сайт на Manus** можно снять с публикации в панели проекта после проверки нового сервера.
- **Служебные файлы Manus** (`app.config.ts`, `public/manus-routes.json`) в этот архив не включены и для работы не нужны.

## 8. Проверка

`https://ваш.домен/healthz` должен вернуть `{"ok":true,"storage":"file"|"database",…}`. Затем войдите как SM-01 / 2468 и откройте вкладку «Диспетчер». На карте должны быть подложка и стоянки мс-01…мс-10. После нажатия «⌖» и разрешения геопозиции появится ваша точка.

| Проблема | Причина и решение |
|---|---|
| GPS не запрашивается | сайт открыт по http, а не https; проверьте сертификат |
| Не работает чат или «коллеги онлайн» | прокси не пропускает WebSocket; нужны заголовки Upgrade/Connection (уже есть в конфигурациях из `deploy/`) |
| `запуск не удался … ECONNREFUSED` | база из `DATABASE_URL` недоступна; проверьте адрес, пароль и что контейнер `db` запущен |
| `self-signed certificate` / ошибка TLS к базе | задайте `DB_SSL=insecure` или `DB_SSL=0` для базы в локальной сети |
| Позиция «вне полигона» | координаты за границами учебного полигона ВДНХ отклоняются намеренно |
