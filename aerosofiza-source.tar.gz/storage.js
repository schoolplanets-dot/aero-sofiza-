'use strict';
/* Аэро-СофИзА · постоянное хранилище состояния.
   Состояние ядра ОТО (заявки, журнал, параметры) и история чата хранятся в управляемой
   базе данных (MySQL-совместимой) как сжатые JSON-документы в таблице app_kv.
   Ядро ОТО работает с адаптером синхронно (load/save/clear), поэтому документы
   загружаются в память при старте, а запись выполняется в фоне (последняя версия побеждает).
   Без DATABASE_URL используется файловое хранилище в DATA_DIR (локальный запуск). */
const fs = require('fs'), path = require('path'), zlib = require('zlib');

const MIGRATIONS = [
  `CREATE TABLE IF NOT EXISTS app_kv (
     k VARCHAR(64) NOT NULL PRIMARY KEY,
     v LONGBLOB NOT NULL,
     updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   )`
];

class DbStore {
  constructor(pool) { this.pool = pool; this.cache = new Map(); this.pending = new Map(); this.busy = new Map(); }
  async init(keys) {
    for (const sql of MIGRATIONS) await this.pool.query(sql);
    const [rows] = await this.pool.query('SELECT k, v FROM app_kv WHERE k IN (?)', [keys]);
    for (const r of rows) { try { this.cache.set(r.k, JSON.parse(zlib.gunzipSync(r.v).toString('utf8'))); } catch (e) { console.warn('[db] повреждён документ', r.k, e.message); } }
  }
  get(k) { return this.cache.has(k) ? this.cache.get(k) : null; }
  set(k, data) { this.cache.set(k, data); this.pending.set(k, data); this._write(k); }
  del(k) { this.cache.delete(k); this.pending.set(k, undefined); this._write(k); }
  async _write(k) {
    if (this.busy.get(k)) return; this.busy.set(k, true);
    try {
      while (this.pending.has(k)) {
        const data = this.pending.get(k); this.pending.delete(k);
        try {
          if (data === undefined) await this.pool.query('DELETE FROM app_kv WHERE k = ?', [k]);
          else await this.pool.query('INSERT INTO app_kv (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)', [k, zlib.gzipSync(JSON.stringify(data))]);
        } catch (e) { console.error('[db] запись', k, e.message); if (!this.pending.has(k)) this.pending.set(k, data); await new Promise(r => setTimeout(r, 3000)); }
      }
    } finally { this.busy.set(k, false); }
  }
  async flush() { const t0 = Date.now(); while ([...this.busy.values()].some(Boolean) || this.pending.size) { if (Date.now() - t0 > 8000) break; await new Promise(r => setTimeout(r, 50)); } }
  async close() { await this.flush(); await this.pool.end(); }
}

class FileStore {
  constructor(dir) { this.dir = dir; fs.mkdirSync(dir, { recursive: true }); }
  async init() { }
  file(k) { return path.join(this.dir, k + '.json'); }
  get(k) { try { return JSON.parse(fs.readFileSync(this.file(k), 'utf8')); } catch (e) { return null; } }
  set(k, data) { try { fs.writeFileSync(this.file(k) + '.tmp', JSON.stringify(data)); fs.renameSync(this.file(k) + '.tmp', this.file(k)); } catch (e) { console.error('[file] запись', k, e.message); } }
  del(k) { try { fs.unlinkSync(this.file(k)); } catch (e) { } }
  async flush() { }
  async close() { }
}

/* TLS к базе: DB_SSL=0 — без шифрования (база в той же сети/Docker), DB_SSL=insecure — без проверки сертификата,
   по умолчанию — TLS с проверкой (облачные MySQL/TiDB). Для localhost и имени сервиса Docker TLS по умолчанию отключён. */
function dbSsl(u) {
  const v = String(process.env.DB_SSL || '').toLowerCase();
  if (v === '0' || v === 'off' || v === 'false') return undefined;
  if (v === 'insecure') return { rejectUnauthorized: false };
  if (!v && /^(localhost|127\.0\.0\.1|db|mysql|mariadb)$/.test(u.hostname) && !u.searchParams.has('ssl')) return undefined;
  return { minVersion: 'TLSv1.2', rejectUnauthorized: true };
}

/* Адаптер для OTO.Store: тот же интерфейс, что у OTO.FileAdapter / LocalStorageAdapter. */
const adapterFor = (store, key) => ({ load: () => store.get(key), save: data => store.set(key, data), clear: () => store.del(key) });

async function openStore({ dataDir, keys }) {
  const dsn = process.env.DATABASE_URL;
  if (dsn) {
    const mysql = require('mysql2/promise');
    const u = new URL(dsn);
    const pool = mysql.createPool({
      host: u.hostname, port: +u.port || 3306, user: decodeURIComponent(u.username), password: decodeURIComponent(u.password),
      database: u.pathname.replace(/^\//, ''), ssl: dbSsl(u),
      waitForConnections: true, connectionLimit: 4, connectTimeout: 15000, enableKeepAlive: true
    });
    const st = new DbStore(pool);
    await st.init(keys);
    st.kind = 'database';
    return st;
  }
  const st = new FileStore(dataDir); await st.init(); st.kind = 'file:' + dataDir; return st;
}

module.exports = { openStore, adapterFor };
