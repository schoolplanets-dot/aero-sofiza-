#!/usr/bin/env node
/* Однократная начальная загрузка архива при первом старте сервиса.
   Ничего не перезаписывает, если в хранилище уже есть oto-store. */
'use strict';
const fs = require('fs');
const path = require('path');
const { openStore } = require('../storage');

const KEYS = ['oto-store', 'chat-history'];
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'data-export');

(async () => {
  const store = await openStore({
    dataDir: process.env.DATA_DIR || path.join(root, 'data'),
    keys: KEYS
  });
  try {
    if (store.get('oto-store')) {
      console.log('[seed] начальные данные уже есть; импорт пропущен');
      return;
    }
    const otoFile = path.join(source, 'oto-store.json');
    if (!fs.existsSync(otoFile)) {
      console.log('[seed] экспорт oto-store.json не найден; пропуск');
      return;
    }
    store.set('oto-store', JSON.parse(fs.readFileSync(otoFile, 'utf8')));
    const chatFile = path.join(source, 'chat-history.json');
    if (fs.existsSync(chatFile)) {
      store.set('chat-history', JSON.parse(fs.readFileSync(chatFile, 'utf8')));
    }
    await store.flush();
    console.log('[seed] исходный экспорт загружен один раз');
  } finally {
    await store.close();
  }
})().catch(error => {
  console.error('[seed] ошибка начальной загрузки:', error.message);
  process.exit(1);
});
