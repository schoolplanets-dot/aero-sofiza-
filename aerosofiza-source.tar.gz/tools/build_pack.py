"""Сборка пакета локации OTO (oto-location-pack/1) из геоданных QGIS + дорожной сети OpenStreetMap.
Вход:  /home/ubuntu/upload/geo/*.geojson, /home/ubuntu/work/osm_roads.json
Выход: /home/ubuntu/work/pack_geo.json, /home/ubuntu/work/net.json (для контрольной картинки)
"""
import json, math
from collections import defaultdict, deque

GEO = '/home/ubuntu/upload/geo'
OSM = json.load(open('/home/ubuntu/work/osm_roads.json'))
load = lambda n: json.load(open(f'{GEO}/{n}.geojson'))['features']
zones_f, ac_f, eng_f, veh_f = load('service_zones'), load('aircrafts_positions'), load('engineers_positions'), load('service_vehicles_positions')

# ---------- проекция ----------
all_pts = [(f['geometry']['coordinates'][1], f['geometry']['coordinates'][0]) for f in ac_f + eng_f + veh_f]
for f in zones_f:
    all_pts += [(c[1], c[0]) for c in f['geometry']['coordinates'][0][0]]
minLat, maxLat = min(p[0] for p in all_pts), max(p[0] for p in all_pts)
minLon, maxLon = min(p[1] for p in all_pts), max(p[1] for p in all_pts)
O = ((minLat + maxLat) / 2, (minLon + maxLon) / 2)
mLat, mLon = 110574, 111320 * math.cos(math.radians(O[0]))
xy = lambda lat, lon: ((lon - O[1]) * mLon, (lat - O[0]) * mLat)
ll = lambda x, y: (O[0] + y / mLat, O[1] + x / mLon)
dist = lambda a, b: math.hypot(a[0] - b[0], a[1] - b[1])
R7 = lambda v: round(v, 7)

# ---------- дорожная сеть OSM ----------
PAD = 0.0022
BB = (minLat - PAD, maxLat + PAD, minLon - PAD * 1.8, maxLon + PAD * 1.8)
VEH = {'service', 'unclassified', 'secondary', 'secondary_link', 'tertiary', 'living_street', 'residential', 'pedestrian'}
SKIP_SERVICE = {'driveway'}
nodes = {k: tuple(v) for k, v in OSM['nodes'].items()}
inb = lambda nid: BB[0] <= nodes[nid][0] <= BB[1] and BB[2] <= nodes[nid][1] <= BB[3]
ways = []
for wid, w in OSM['ways'].items():
    t = w['tags']; hw = t['highway']
    if hw not in VEH or t.get('service') in SKIP_SERVICE or t.get('access') in ('private', 'no') and hw != 'service':
        continue
    seq = [n for n in w['nodes'] if n in nodes]
    # обрезка по bbox: разбиваем на куски внутри
    cur = []
    for n in seq:
        if inb(n): cur.append(n)
        else:
            if len(cur) > 1: ways.append((wid, cur, t))
            cur = []
    if len(cur) > 1: ways.append((wid, cur, t))

use = defaultdict(int)
for _, seq, _ in ways:
    for i, n in enumerate(seq):
        use[n] += 2 if i in (0, len(seq) - 1) else 1
junction = {n for n, c in use.items() if c >= 2}

def dp(points, tol):
    if len(points) < 3: return points
    a, b = points[0], points[-1]
    ax, ay = xy(*nodes[a]); bx, by = xy(*nodes[b])
    best, bi = -1, -1
    for i in range(1, len(points) - 1):
        px, py = xy(*nodes[points[i]])
        dx, dy = bx - ax, by - ay; L2 = dx * dx + dy * dy or 1
        t = max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L2))
        d = math.hypot(px - ax - t * dx, py - ay - t * dy)
        if d > best: best, bi = d, i
    if best <= tol: return [a, b]
    return dp(points[:bi + 1], tol)[:-1] + dp(points[bi:], tol)

TOL = 7.0
segs = []  # (a, b, tags)
for wid, seq, t in ways:
    chain = [seq[0]]
    for n in seq[1:]:
        chain.append(n)
        if n in junction:
            s = dp(chain, TOL)
            for i in range(len(s) - 1): segs.append((s[i], s[i + 1], t))
            chain = [n]
    if len(chain) > 1:
        s = dp(chain, TOL)
        for i in range(len(s) - 1): segs.append((s[i], s[i + 1], t))

# крупнейшая связная компонента
adj = defaultdict(set)
for a, b, _ in segs:
    if a != b: adj[a].add(b); adj[b].add(a)
seen, comps = set(), []
for s in adj:
    if s in seen: continue
    comp, q = set([s]), deque([s]); seen.add(s)
    while q:
        u = q.popleft()
        for v in adj[u]:
            if v not in seen: seen.add(v); comp.add(v); q.append(v)
    comps.append(comp)
main = max(comps, key=len)
segs = [s for s in segs if s[0] in main and s[1] in main and s[0] != s[1]]

# обрезка коротких тупиков (итеративно), чтобы граф был компактным
def prune(segs, minlen=25, rounds=4):
    for _ in range(rounds):
        deg = defaultdict(int)
        for a, b, _ in segs: deg[a] += 1; deg[b] += 1
        out = []
        for a, b, t in segs:
            L = dist(xy(*nodes[a]), xy(*nodes[b]))
            if (deg[a] == 1 or deg[b] == 1) and L < minlen: continue
            out.append((a, b, t))
        if len(out) == len(segs): break
        segs = out
    return segs
segs = prune(segs)
# дедупликация рёбер
uniq = {}
for a, b, t in segs:
    k = tuple(sorted((a, b)))
    if k not in uniq: uniq[k] = (a, b, t)
segs = list(uniq.values())

# ---------- узлы и рёбра пакета ----------
P_nodes, P_edges = [], []
nid_map = {}
deg = defaultdict(int)
for a, b, _ in segs: deg[a] += 1; deg[b] += 1
for n in sorted({x for s in segs for x in s[:2]}):
    i = f'R{len(nid_map) + 1:03d}'; nid_map[n] = i
    lat, lon = nodes[n]
    P_nodes.append({'id': i, 'name': 'Перекрёсток' if deg[n] >= 3 else 'Точка дороги', 'kind': 'junction' if deg[n] >= 3 else 'bend', 'lat': R7(lat), 'lon': R7(lon)})
NODE = {n['id']: n for n in P_nodes}
def edge(a, b, kind, name, modes, speedClass, oneway=False):
    A, B = NODE[a], NODE[b]
    L = dist(xy(A['lat'], A['lon']), xy(B['lat'], B['lon']))
    P_edges.append({'id': f'E{len(P_edges) + 1}', 'from': a, 'to': b, 'kind': kind, 'name': name, 'oneway': oneway, 'modes': modes,
                    'lengthM': max(1, round(L, 1)), 'speedClass': speedClass, 'clearance': False})
for a, b, t in segs:
    hw = t['highway']; nm = t.get('name') or {'service': 'Служебный проезд', 'pedestrian': 'Пешеходная зона', 'secondary': 'Улица', 'unclassified': 'Проезд'}.get(hw, 'Проезд')
    if t.get('service') == 'parking_aisle': nm = 'Проезд парковки'
    sc = 'other' if hw in ('secondary', 'secondary_link', 'tertiary', 'unclassified') else 'apron'
    edge(nid_map[a], nid_map[b], 'service_road', nm, ['vehicle', 'foot'], sc, oneway=(t.get('oneway') == 'yes'))

road_ids = [n['id'] for n in P_nodes]
def nearest_road_point(lat, lon):
    """Ближайшая точка на ребре сети: вставляем новый узел в ребро (разбиваем ребро)."""
    p = xy(lat, lon); best = None
    for e in P_edges:
        if e['kind'] != 'service_road': continue
        A, B = NODE[e['from']], NODE[e['to']]
        a, b = xy(A['lat'], A['lon']), xy(B['lat'], B['lon'])
        dx, dy = b[0] - a[0], b[1] - a[1]; L2 = dx * dx + dy * dy or 1
        t = max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
        q = (a[0] + t * dx, a[1] + t * dy); d = dist(p, q)
        if not best or d < best[0]: best = (d, e, t, q)
    d, e, t, q = best
    if t < 0.08 or e['lengthM'] * t < 4: return e['from'], d
    if t > 0.92 or e['lengthM'] * (1 - t) < 4: return e['to'], d
    lat2, lon2 = ll(*q)
    nid = f'J{len(P_nodes) + 1:03d}'
    P_nodes.append({'id': nid, 'name': 'Съезд', 'kind': 'junction', 'lat': R7(lat2), 'lon': R7(lon2)}); NODE[nid] = P_nodes[-1]
    old_to = e['to']; L = e['lengthM']
    e['to'] = nid; e['lengthM'] = max(1, round(L * t, 1))
    P_edges.append(dict(e, id=f'E{len(P_edges) + 1}', **{'from': nid, 'to': old_to, 'lengthM': max(1, round(L * (1 - t), 1))}))
    return nid, d

# ---------- стоянки (зоны обслуживания) ----------
def centroid(ring):
    pts = [xy(c[1], c[0]) for c in ring[:-1]]
    A = cx = cy = 0
    for i in range(len(pts)):
        x0, y0 = pts[i]; x1, y1 = pts[(i + 1) % len(pts)]
        c = x0 * y1 - x1 * y0; A += c; cx += (x0 + x1) * c; cy += (y0 + y1) * c
    A /= 2
    return ll(cx / (6 * A), cy / (6 * A))
def heading_of(ring):
    pts = [xy(c[1], c[0]) for c in ring[:-1]]
    best = (0, 0)
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        L = dist(a, b)
        if L > best[0]: best = (L, (math.degrees(math.atan2(b[0] - a[0], b[1] - a[1])) + 360) % 180)
    return round(best[1])
def pip(p, ring):
    x, y = p; inside = False; n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]; x2, y2 = ring[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1: inside = not inside
    return inside

stands, areas = [], []
for f in sorted(zones_f, key=lambda f: f['properties']['id']):
    pid = f['properties']['id']; nm = f['properties']['name']
    ring = f['geometry']['coordinates'][0][0]
    clat, clon = centroid(ring)
    sid = f'MS{pid:02d}'
    acc = f'SA_{sid}'
    P_nodes.append({'id': acc, 'name': f'Место стоянки {nm}', 'kind': 'stand_access', 'lat': R7(clat), 'lon': R7(clon)}); NODE[acc] = P_nodes[-1]
    rn, d = nearest_road_point(clat, clon)
    edge(acc, rn, 'stand_lane', f'Подъезд к {nm}', ['vehicle', 'foot'], 'stand')
    poly = [[R7(c[1]), R7(c[0])] for c in ring[:-1]]
    stands.append({'id': sid, 'name': f'Стоянка {nm}', 'nodeId': acc, 'lat': R7(clat), 'lon': R7(clon), 'heading': heading_of(ring),
                   'acTypes': ['A32X'], 'remote': False, 'geoId': pid, 'geoName': nm, 'polygon': poly, 'linkM': round(d)})
    areas.append({'id': f'A_{sid}', 'kind': 'apron', 'label': '', 'polygon': poly})

# ---------- объекты (условные, рядом с данными геослоёв) ----------
def ptf(feats, key, val):
    f = next(x for x in feats if x['properties'].get(key) == val); return f['geometry']['coordinates'][1], f['geometry']['coordinates'][0]
facilities = []
def fac(fid, name, kind, lat, lon):
    nid = f'F_{fid}'
    P_nodes.append({'id': nid, 'name': name, 'kind': 'facility', 'lat': R7(lat), 'lon': R7(lon)}); NODE[nid] = P_nodes[-1]
    rn, d = nearest_road_point(lat, lon)
    edge(nid, rn, 'stand_lane', f'Подход: {name}', ['vehicle', 'foot'], 'stand')
    facilities.append({'id': fid, 'name': name, 'kind': kind, 'nodeId': nid, 'lat': R7(lat), 'lon': R7(lon)})
t1 = ptf(eng_f, 'tabel_id', 'AT-0001'); v3 = ptf(veh_f, 'object_id', 'vehicle-03'); v1 = ptf(veh_f, 'object_id', 'vehicle-01')
fac('TECH', 'База ОТО (учебная)', 'tech_center', (t1[0] + v3[0]) / 2, (t1[1] + v3[1]) / 2)
fac('VEHPARK', 'Стоянка спецтранспорта', 'vehicle_park', v1[0], v1[1])
fac('TOOLS', 'Склад инструмента (учебный)', 'tool_crib', v1[0] + 0.00018, v1[1] - 0.00035)

# ---------- стартовые данные ----------
AT2AG = {'AT-0001': ('AG-01', 'Иван Петров', '#387f9c'), 'AT-0002': ('AG-02', 'Мария Соколова', '#6c70ab'), 'AT-0003': ('AG-03', 'Артём Волков', '#be6d46'),
         'AT-0004': ('AG-04', 'Елена Смирнова', '#288576'), 'AT-0005': ('AG-05', 'Данил Каримов', '#617887'), 'AT-0006': ('AG-06', 'Анна Белова', '#ba8a38'),
         'AT-0007': ('AG-07', 'Павел Орлов', '#8a5ba3')}
ATA_B1 = [5, 12, 21, 24, 26, 27, 28, 29, 30, 32, 33, 36, 49, 52, 53, 54, 55, 56, 57, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]
ATA_B2 = [22, 23, 24, 31, 33, 34, 42, 44, 45, 46]
ATA_CAB = [25, 33, 35, 38, 44]
ATA_AM = [12, 25, 32]
engineers = []
for f in eng_f:
    p = f['properties']; lon, lat = f['geometry']['coordinates']
    ag, name, col = AT2AG[p['tabel_id']]
    skills = [s.strip() for s in p['skill'].split(',')]
    ata = set()
    for s in skills: ata |= set({'B1': ATA_B1, 'B2': ATA_B2, 'CAB': ATA_CAB, 'AM': ATA_AM, 'A': [12, 32]}.get(s, []))
    engineers.append({'id': ag, 'name': name, 'role': f"{p['grade']} {p['skill']} · {p['scope']} ({p['scope_desc'].replace(';', ', ')}) · таб. {p['tabel_id']}",
                      'authorizations': [{'types': ['A32X'], 'ata': sorted(ata)}],
                      'tools': (['borescope', 'torque'] if p['grade'] == 'Инженер' else ['torque']) if 'B1' in skills else (['jack'] if 'AM' in skills else []),
                      'mobility': 'foot', 'start': {'lat': R7(lat), 'lon': R7(lon)}, 'color': col, 'tabelId': p['tabel_id'], 'grade': p['grade'],
                      'skill': p['skill'], 'scope': p['scope'], 'senior': p['grade'] == 'Инженер' and 'B1' in skills})
VT = {'vehicle-01': 'van', 'vehicle-02': 'van', 'vehicle-03': 'scooter'}
vehicles = []
for f in veh_f:
    p = f['properties']; lon, lat = f['geometry']['coordinates']
    vehicles.append({'id': p['object_id'], 'name': p['model'], 'type': VT.get(p['object_id'], 'van'), 'start': {'lat': R7(lat), 'lon': R7(lon)}})
# учебная спецтехника (в геоданных отсутствует; помечена явно)
vehicles.append({'id': 'V-TRAP', 'name': 'Автотрап (учебный)', 'type': 'stairs', 'startNode': 'F_VEHPARK', 'training': True})
vehicles.append({'id': 'V-LIFT', 'name': 'Подъёмник (учебный)', 'type': 'lift', 'startNode': 'F_VEHPARK', 'training': True})
aircraft, flights = [], []
FL = ['SU1201', 'SU1844', 'SU2012', 'SU0220', 'SU1415', 'SU6030', 'SU0211', 'SU1701', 'SU1530', 'SU1888']
for i, f in enumerate(ac_f):
    p = f['properties']; lon, lat = f['geometry']['coordinates']; q = xy(lat, lon)
    st = None
    for s in stands:
        if pip(q, [xy(a, b) for a, b in s['polygon']]): st = s; break
    if not st: st = min(stands, key=lambda s: dist(q, xy(s['lat'], s['lon'])))
    aircraft.append({'regNo': p['object_id'], 'type': 'A320', 'family': 'A32X', 'stand': st['id'], 'model': p['name'], 'geo': {'lat': R7(lat), 'lon': R7(lon)}})
    st['lat'], st['lon'] = R7(lat), R7(lon)  # ВС стоит в точке из слоя aircrafts_positions
    flights.append({'flight': FL[i % len(FL)], 'regNo': p['object_id'], 'stdOffsetMin': 30 + 12 * i, 'standId': st['id']})

pad = 0.0016
pack = {
    'schema': 'oto-location-pack/1', 'id': 'VDNH-GEO', 'name': 'Учебный полигон ВДНХ · геоданные QGIS', 'icao': 'ГЕО', 'timezone': '+03:00',
    'origin': {'lat': R7(O[0]), 'lon': R7(O[1])},
    'bounds': {'minLat': R7(minLat - pad), 'maxLat': R7(maxLat + pad), 'minLon': R7(minLon - pad * 1.8), 'maxLon': R7(maxLon + pad * 1.8)},
    'params': {}, 'nodes': P_nodes, 'edges': P_edges, 'stands': stands, 'facilities': facilities, 'zones': [], 'areas': areas, 'taxiRoutes': [],
    'seed': {'engineers': engineers, 'vehicles': vehicles, 'aircraft': aircraft, 'flights': flights},
    'source': {'geodata': 'geodata_for_final.zip (QGIS, EPSG:4326): service_zones, aircrafts_positions, engineers_positions, service_vehicles_positions',
               'roads': 'OpenStreetMap contributors (ODbL), highway=service/unclassified/secondary и др., упрощение Дугласа–Пекера 7 м',
               'note': 'Учебные данные. Не для реальной навигации.'}
}
json.dump(pack, open('/home/ubuntu/work/pack_geo.json', 'w'), ensure_ascii=False, separators=(',', ':'))
json.dump({'nodes': P_nodes, 'edges': P_edges}, open('/home/ubuntu/work/net.json', 'w'))
print('nodes', len(P_nodes), 'edges', len(P_edges), 'stands', len(stands), [(s['geoName'], s['linkM']) for s in stands])
print('aircraft', [(a['regNo'], a['stand']) for a in aircraft])
print('bounds', pack['bounds'], 'size KB', len(json.dumps(pack, ensure_ascii=False)) // 1024)
