"""Сборка public/index.html: копия исходного HTML + точечные дополнения (структура и интерфейс исходника сохраняются)."""
import json, re, sys
SRC = '/home/ubuntu/upload/Админавтотрап_ОТО.html'
OUT = '/home/ubuntu/aero-sofiza-app/public/index.html'
W = '/home/ubuntu/work'
h = open(SRC, encoding='utf-8').read()
n0 = len(h)

def rep(old, new, count=1):
    global h
    c = h.count(old)
    if c != count: sys.exit(f'ожидалось {count} вхождений, найдено {c}: {old[:90]!r}')
    h = h.replace(old, new)

pack = json.load(open(f'{W}/pack_geo.json', encoding='utf-8'))
pj = json.dumps(pack, ensure_ascii=False, separators=(',', ':'))
assert '</' not in pj
leaf_js = open('/tmp/package/dist/leaflet.js', encoding='utf-8').read().replace('//# sourceMappingURL=leaflet.js.map', '')
leaf_css = open('/tmp/package/dist/leaflet.css', encoding='utf-8').read()
geo_css = open(f'{W}/src/geo.css', encoding='utf-8').read()
geo_oto = open(f'{W}/src/geo-oto.js', encoding='utf-8').read()
geo_orig = open(f'{W}/src/geo-orig.js', encoding='utf-8').read()

# 1) <head>: PWA-метаданные, Leaflet (BSD-2), стили геокарты
rep('  <meta name="theme-color" content="#101d2b">\n',
    '  <meta name="theme-color" content="#101d2b">\n'
    '  <link rel="manifest" href="manifest.webmanifest">\n'
    '  <link rel="icon" href="icons/icon-192.png" type="image/png">\n'
    '  <link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n'
    '  <meta name="apple-mobile-web-app-capable" content="yes">\n'
    '  <meta name="mobile-web-app-capable" content="yes">\n'
    '  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n'
    '  <meta name="apple-mobile-web-app-title" content="Аэро-СофИзА">\n')
rep('</style>\n</head>', '</style>\n<style id="leaflet-css">/* Leaflet 1.9.4 · BSD-2-Clause · (c) Volodymyr Agafonkin, CloudMade */\n' + leaf_css +
    '</style>\n<style id="geo-css">\n' + geo_css + '</style>\n<script id="leaflet-js">/* Leaflet 1.9.4 · https://leafletjs.com · BSD-2-Clause */\n' + leaf_js + '\n</script>\n</head>')

# 2) пакет локации по геоданным — сразу после встроенных пакетов (попадает и в серверное ядро)
m = re.search(r'globalThis\.OTO = globalThis\.OTO \|\| \{\}; OTO\.PACKS = .*\n', h)
assert m
h = h[:m.end()] + '/* пакет локации VDNH-GEO: собран из geodata_for_final.zip (QGIS) + проезды OpenStreetMap (ODbL) */\nOTO.PACKS["VDNH-GEO"] = ' + pj + ';\nOTO.DEFAULT_PACK = "VDNH-GEO"; OTO.LIVE_SOURCES = ["browser-gps", "device-gps", "tracker"];\n' + h[m.end():]

# 3) имитатор не «водит» сотрудников и транспорт, чьи координаты приходят с реального GPS
rep("const E = S.eng[A.id]; if (!E || !A.onShift) continue; if (S.manual.has(A.id) || !S.settings.autopilot) continue;",
    "const E = S.eng[A.id]; if (!E || !A.onShift) continue; if (S.manual.has(A.id) || !S.settings.autopilot) continue;\n"
    "        if (A.position && OTO.LIVE_SOURCES.includes(A.position.source) && S.now - (A.position.recvAt || 0) < 90000 * (S.scale || 1)) continue; /* живой GPS устройства */")
rep("for (const V of state.vehicles) {\n        if (!V.position) continue;",
    "for (const V of state.vehicles) {\n        if (!V.position) continue;\n"
    "        if (OTO.LIVE_SOURCES.includes(V.position.source) && S.now - (V.position.recvAt || 0) < 90000 * (S.scale || 1)) continue; /* живой трекер */ ")

# 4) запуск: адрес REST-сервера приложения, пакет по умолчанию
rep("const q = new URLSearchParams(location.search), apiUrl = q.get('api');",
    "const q = new URLSearchParams(location.search), apiUrl = q.get('api') === 'local' ? null : (q.get('api') || root.OTO_API_URL || null);")
rep("if (apiUrl) transport = new OTO.HttpTransport(apiUrl);",
    "if (apiUrl) { transport = new OTO.HttpTransport(apiUrl); if (root.OTO_API_URL && !q.get('sim')) this.simStopped = true; /* имитатор работает на сервере */ }")
rep("defaultPackId: 'SVO-DEMO', adapter: new OTO.LocalStorageAdapter(LS_KEY)",
    "defaultPackId: OTO.DEFAULT_PACK || 'SVO-DEMO', adapter: new OTO.LocalStorageAdapter(LS_KEY)")
rep('onclick="location.href=location.pathname"', 'onclick="location.href=location.pathname+\'?api=local\'"')

# 5) модуль подложки/GPS — перед финальным запуском режима ОТО
anchor = "(function () {\n  'use strict';\n  var rootEl = document.getElementById('otoRoot')"
rep(anchor, geo_oto + anchor)

# 6) фрейм «Геокарта» исходной программы и регистрация service worker
rep('</script>\n</body>', '</script>\n<script id="geo-frame">\n' + geo_orig +
    "</script>\n<script id=\"pwa\">\nif ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));\n</script>\n</body>")

open(OUT, 'w', encoding='utf-8').write(h)
print('ok', n0, '->', len(h))
