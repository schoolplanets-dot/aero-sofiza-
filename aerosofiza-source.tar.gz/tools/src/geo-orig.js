/* ===== Геокарта исходной программы (дополнение, исходные функции не переписываются) =====
   Фрейм карты по геоданным QGIS (service_zones, aircrafts_positions, engineers_positions, service_vehicles_positions)
   в блоке .map-wrap. Синхронизация со схемой: стоянки S01…S06 ⇄ зоны мс-01…мс-06, узлы TECH/GATE/CROSS — объекты полигона,
   сотрудники AGENTS — по своим узлам, маршрут currentRoute() — по реальным проездам (граф OSM из пакета VDNH-GEO),
   автотрап — анимация вдоль маршрута, GPS устройства — маркер, точность, следование и привязка вошедшего сотрудника к узлу. */
(function () {
  'use strict';
  if (typeof L === 'undefined' || typeof OTO === 'undefined' || !OTO.PACKS || typeof NODES === 'undefined') return;
  const PACK = OTO.PACKS[OTO.DEFAULT_PACK || 'VDNH-GEO']; if (!PACK) return;
  const G = new OTO.RoadGraph(JSON.parse(JSON.stringify(PACK)));
  const proj = OTO.Projector(PACK.origin);
  const LINK = { S01: 'MS01', S02: 'MS02', S03: 'MS03', S04: 'MS04', S05: 'MS05', S06: 'MS06' };
  const UNLINK = Object.fromEntries(Object.entries(LINK).map(([a, b]) => [b, a]));
  const standById = id => PACK.stands.find(s => s.id === id);
  const fac = id => (PACK.facilities || []).find(f => f.id === id);
  // геопривязка узлов схемы
  const GEO_NODE = {};
  Object.entries(LINK).forEach(([sid, ms]) => { const s = standById(ms); GEO_NODE[sid] = { nodeId: s.nodeId, lat: s.lat, lon: s.lon, name: s.geoName }; });
  const ft = fac('TECH'), fv = fac('VEHPARK');
  GEO_NODE.TECH = { nodeId: ft.nodeId, lat: ft.lat, lon: ft.lon, name: ft.name };
  GEO_NODE.GATE = { nodeId: fv.nodeId, lat: fv.lat, lon: fv.lon, name: 'Сервисный въезд · ' + fv.name };
  (function () { // центральный узел — перекрёсток у центра стоянок мс-01…мс-06
    const pts = Object.values(LINK).map(standById), c = { lat: pts.reduce((s, p) => s + p.lat, 0) / pts.length, lon: pts.reduce((s, p) => s + p.lon, 0) / pts.length };
    let best = null; for (const n of PACK.nodes) { if (n.kind !== 'junction') continue; const a = proj.toXY(n), b = proj.toXY(c), d = Math.hypot(a.x - b.x, a.y - b.y); if (!best || d < best.d) best = { n, d }; }
    GEO_NODE.CROSS = { nodeId: best.n.id, lat: best.n.lat, lon: best.n.lon, name: 'Центральный узел (перекрёсток)' };
  })();
  window.GEO_NODE = GEO_NODE;
  // учебная локация «ВДНХ · геоданные» в списке аэропортов (схема остаётся прежней, координаты — из геоданных)
  try {
    if (typeof AIRPORTS !== 'undefined' && !AIRPORTS.GEO) {
      AIRPORTS.GEO = { name: 'Учебный полигон ВДНХ', code: 'ГЕО', standPrefix: 'МС', gps: `${PACK.origin.lat.toFixed(6)},${PACK.origin.lon.toFixed(6)}`, positions: JSON.parse(JSON.stringify(AIRPORTS.SVO.positions)) };
      const sel = document.getElementById('airportSelect'); if (sel) { const o = document.createElement('option'); o.value = 'GEO'; o.textContent = 'ВДНХ · геоданные (ГЕО)'; sel.appendChild(o); }
    }
  } catch (e) { /* */ }

  // ---------- разметка фрейма ----------
  const wrap = document.querySelector('.map-panel .map-wrap'); if (!wrap) return;
  const sec = document.createElement('section'); sec.className = 'geo-frame'; sec.setAttribute('aria-label', 'Геокарта по геоданным');
  sec.innerHTML = `<div class="geo-head"><div><div class="gps-heading">Геокарта · учебный полигон (геоданные QGIS)</div>
      <div class="geo-sub" id="geoSub">Стоянки схемы Р01–Р06 ⇄ зоны обслуживания мс-01…мс-06 · маршрут по реальным проездам</div></div>
      <div class="geo-tools"><select id="geoBase" aria-label="Подложка карты"><option value="dark">Тёмная</option><option value="osm">OSM</option><option value="sat">Спутник</option><option value="none">Без подложки</option></select>
      <button class="small-button" id="geoFit" type="button" title="Весь полигон">⤢ Полигон</button><button class="small-button" id="geoFollow" type="button" title="Следовать за GPS">⌖ GPS</button></div></div>
    <div class="geo-map" id="geoMap" role="application" aria-label="Карта полигона"></div>
    <div class="geo-status" id="geoStatus" role="status" aria-live="polite">GPS не активирован · нажмите «⌖ GPS» или «◎ Определить моё положение».</div>`;
  const gpsPanel = wrap.querySelector('.gps-panel'); wrap.insertBefore(sec, gpsPanel || null);
  const $g = id => document.getElementById(id);
  const map = L.map('geoMap', { zoomControl: true, attributionControl: true, zoomSnap: 0.25, maxZoom: 21, preferCanvas: false });
  map.attributionControl.setPrefix(false);
  const B = OTO.GEO && OTO.GEO.BASEMAPS || {};
  let baseLayer = null;
  function setBase(k) { if (baseLayer) map.removeLayer(baseLayer); baseLayer = null; const d = B[k]; if (d && d.url) baseLayer = L.tileLayer(d.url, Object.assign({ maxZoom: 21 }, d.opt)).addTo(map); sec.dataset.base = k; try { localStorage.setItem('oto-basemap', k); } catch (e) { /* */ } }
  let pref = 'dark'; try { pref = localStorage.getItem('oto-basemap') || 'dark'; } catch (e) { /* */ }
  $g('geoBase').value = B[pref] ? pref : 'dark'; setBase($g('geoBase').value);
  $g('geoBase').onchange = e => setBase(e.target.value);
  const bnd = L.latLngBounds(PACK.stands.map(s => [s.lat, s.lon]).concat((PACK.facilities || []).map(f => [f.lat, f.lon])));
  const fit = () => map.fitBounds(bnd.pad(0.08));
  fit(); $g('geoFit').onclick = () => { follow = false; btnState(); fit(); };

  // ---------- слои геоданных ----------
  const panes = ['zones', 'route', 'objs', 'agents', 'gps']; panes.forEach((p, i) => { map.createPane('geo-' + p); map.getPane('geo-' + p).style.zIndex = 410 + i * 10; });
  const lyr = { roads: L.layerGroup().addTo(map), zones: L.layerGroup().addTo(map), aircraft: L.layerGroup().addTo(map), vehicles: L.layerGroup().addTo(map), engineers: L.layerGroup(), agents: L.layerGroup().addTo(map), route: L.layerGroup().addTo(map), gps: L.layerGroup().addTo(map), live: L.layerGroup().addTo(map) };
  L.control.layers(null, { 'Проезды (граф)': lyr.roads, 'Зоны обслуживания': lyr.zones, 'ВС (геоданные)': lyr.aircraft, 'Транспорт': lyr.vehicles, 'Исходные точки инженеров': lyr.engineers, 'Сотрудники схемы': lyr.agents, 'Маршрут': lyr.route, 'GPS': lyr.gps, 'Коллеги онлайн': lyr.live }, { collapsed: true, position: 'topright' }).addTo(map);
  (function roads() { const idx = {}; PACK.nodes.forEach(n => idx[n.id] = n); const segs = PACK.edges.map(e => [[idx[e.from].lat, idx[e.from].lon], [idx[e.to].lat, idx[e.to].lon]]); L.polyline(segs, { color: '#64748b', weight: 2, opacity: .55, interactive: false, pane: 'geo-zones' }).addTo(lyr.roads); })();
  const div = (cls, html, sz) => L.divIcon({ className: 'geo-ic ' + cls, html, iconSize: sz || [24, 24], iconAnchor: [(sz || [24, 24])[0] / 2, (sz || [24, 24])[1] / 2] });
  const esc2 = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const zoneLayers = {};
  function zoneClick(msId) {
    const sid = UNLINK[msId];
    if (!sid) { if (typeof toast === 'function') toast(`Зона ${standById(msId).geoName} не связана со стоянками схемы Р01–Р06`); return; }
    const el = document.querySelector(`#airportMap [data-node="${sid}"]`); if (el) el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  }
  function drawZones(features) {
    lyr.zones.clearLayers();
    const list = features ? features.map(f => ({ id: 'MS' + String(f.properties.id).padStart(2, '0'), name: f.properties.name, rings: f.geometry.type === 'MultiPolygon' ? f.geometry.coordinates.map(p => p[0].map(c => [c[1], c[0]])) : [f.geometry.coordinates[0].map(c => [c[1], c[0]])] }))
      : PACK.stands.map(s => ({ id: s.id, name: s.geoName, rings: [s.polygon] }));
    list.forEach(z => {
      const linked = !!UNLINK[z.id];
      const pl = L.polygon(z.rings, { pane: 'geo-zones', color: linked ? '#38bdf8' : '#94a3b8', weight: 2, fillOpacity: .18, dashArray: linked ? null : '4 4' }).addTo(lyr.zones);
      pl.bindTooltip(`${esc2(z.name)}${linked ? ' ⇄ ' + esc2(NODES[UNLINK[z.id]].short) : ''}`, { permanent: true, direction: 'top', className: 'geo-tt', offset: [0, -6] });
      pl.on('click', () => zoneClick(z.id)); zoneLayers[z.id] = pl;
    });
  }
  function drawPoints(name, feats, fallback) {
    if (name === 'aircraft') {
      lyr.aircraft.clearLayers();
      const items = feats ? feats.map(f => ({ reg: f.properties.object_id, model: f.properties.name, lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0] })) : PACK.seed.aircraft.map(a => ({ reg: a.regNo, model: a.model, lat: a.geo.lat, lon: a.geo.lon }));
      items.forEach(a => L.marker([a.lat, a.lon], { pane: 'geo-objs', icon: div('geo-ac', '✈', [22, 22]), title: a.reg }).bindPopup(`<b>${esc2(a.reg)}</b><br>${esc2(a.model || 'Airbus A320')}`).addTo(lyr.aircraft));
    }
    if (name === 'vehicles') {
      lyr.vehicles.clearLayers();
      const items = feats ? feats.map(f => ({ id: f.properties.object_id, name: f.properties.model, lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0] })) : PACK.seed.vehicles.filter(v => v.start).map(v => ({ id: v.id, name: v.name, lat: v.start.lat, lon: v.start.lon }));
      items.forEach(v => { const m = L.marker([v.lat, v.lon], { pane: 'geo-objs', icon: div('geo-veh', /самокат/i.test(v.name) ? 'С' : 'А', [20, 20]), title: v.name }).bindPopup(`<b>${esc2(v.name)}</b><br>${esc2(v.id)}`).addTo(lyr.vehicles); vehMarkers[v.id] = m; });
    }
    if (name === 'engineers') {
      lyr.engineers.clearLayers();
      const items = feats ? feats.map(f => ({ id: f.properties.tabel_id, t: `${f.properties.grade} ${f.properties.skill} · ${f.properties.scope_desc}`, lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0] })) : PACK.seed.engineers.map(e => ({ id: e.tabelId, t: e.role, lat: e.start.lat, lon: e.start.lon }));
      items.forEach(e => L.circleMarker([e.lat, e.lon], { pane: 'geo-objs', radius: 5, color: '#a5b4fc', weight: 2, fillOpacity: .4 }).bindPopup(`<b>${esc2(e.id)}</b><br>${esc2(e.t)}`).addTo(lyr.engineers));
    }
  }
  const vehMarkers = {};
  drawZones(null); drawPoints('aircraft'); drawPoints('vehicles'); drawPoints('engineers');
  // если приложение открыто с сервера — берём актуальные файлы geodata/*.geojson (их можно заменить выгрузкой из QGIS)
  if (location.protocol.startsWith('http')) {
    const get = n => fetch('geodata/' + n + '.geojson', { cache: 'no-cache' }).then(r => r.ok ? r.json() : null).catch(() => null);
    get('service_zones').then(j => j && j.features && drawZones(j.features)).then(syncSelected);
    get('aircrafts_positions').then(j => j && j.features && drawPoints('aircraft', j.features));
    get('service_vehicles_positions').then(j => j && j.features && drawPoints('vehicles', j.features));
    get('engineers_positions').then(j => j && j.features && drawPoints('engineers', j.features));
  }
  // объекты схемы
  [['TECH', 'Т', 'geo-fac'], ['GATE', 'В', 'geo-fac'], ['CROSS', '+', 'geo-cross']].forEach(([id, g, c]) => L.marker([GEO_NODE[id].lat, GEO_NODE[id].lon], { pane: 'geo-objs', icon: div(c, g, [22, 22]), title: GEO_NODE[id].name }).bindTooltip(`${esc2(NODES[id].label)} · ${esc2(GEO_NODE[id].name)}`).addTo(lyr.zones));

  // ---------- синхронизация со схемой ----------
  const routeCache = {};
  function roadPath(ids) {
    const key = ids.join('>'); if (routeCache[key]) return routeCache[key];
    const pts = ids.map(id => GEO_NODE[id]).filter(Boolean); if (pts.length < 2) return null;
    const r = G.route({ from: { nodeId: pts[0].nodeId }, to: { nodeId: pts[pts.length - 1].nodeId }, via: pts.slice(1, -1).map(p => ({ nodeId: p.nodeId })), mode: 'vehicle' });
    const out = r && r.ok ? { pts: r.points.map(p => Array.isArray(p) ? p : [p.lat, p.lon]), distanceM: r.distanceM, durationS: r.durationS, viaIdx: r.viaIdx || [] } : { pts: pts.map(p => [p.lat, p.lon]), distanceM: 0, durationS: 0, viaIdx: [] };
    routeCache[key] = out; return out;
  }
  function syncSelected() {
    Object.entries(zoneLayers).forEach(([ms, pl]) => { const sid = UNLINK[ms], on = sid && sid === state.activeStand; pl.setStyle({ color: on ? '#e78b35' : sid ? '#38bdf8' : '#94a3b8', weight: on ? 3.5 : 2, fillOpacity: on ? .35 : .18 }); });
  }
  let lastRouteKey = '';
  function geoRender() {
    syncSelected();
    // сотрудники по узлам схемы
    lyr.agents.clearLayers(); const offs = {};
    const sh = [[0, 0], [14, -10], [-14, 10], [14, 11], [-14, -11], [0, 17]];
    AGENTS.forEach(a => {
      if (state.automatedTransport && state.ticketStatus === 'enroute' && state.assignment && state.assignment.agentId === a.id) return;
      const g = GEO_NODE[a.node]; if (!g) return; const i = offs[a.node] || 0; offs[a.node] = i + 1;
      const act = state.assignment && state.assignment.agentId === a.id;
      const ic = L.divIcon({ className: 'geo-ic geo-agent' + (act ? ' act' : '') + (a.availability === 'free' ? '' : ' busy') + (a.gpsLive ? ' live' : ''), html: `<span style="background:${a.color}">${esc2(a.initials)}</span>`, iconSize: [26, 26], iconAnchor: [13 - sh[i % 6][0], 13 - sh[i % 6][1]] });
      L.marker([g.lat, g.lon], { pane: 'geo-agents', icon: ic, title: a.name }).bindTooltip(`${esc2(a.name)} · ${esc2(NODES[a.node].short)}${a.gpsLive ? ' · по GPS' : ''}`).addTo(lyr.agents);
    });
    // маршрут
    const r = typeof currentRoute === 'function' ? currentRoute() : null;
    const key = r && r.nodes && r.nodes.length > 1 ? r.nodes.join('>') + (r.assigned ? 'A' : 'P') : '';
    if (key !== lastRouteKey) {
      lastRouteKey = key; lyr.route.clearLayers();
      if (key) {
        const p = roadPath(r.nodes);
        if (p) {
          L.polyline(p.pts, { pane: 'geo-route', color: '#0f172a', weight: 9, opacity: .7, interactive: false }).addTo(lyr.route);
          L.polyline(p.pts, { pane: 'geo-route', color: '#e78b35', weight: 5, dashArray: r.assigned ? null : '2 9', lineCap: 'round', interactive: false }).addTo(lyr.route);
          L.circleMarker(p.pts[0], { pane: 'geo-route', radius: 6, color: '#fff', weight: 2, fillColor: '#e78b35', fillOpacity: 1 }).addTo(lyr.route);
          $g('geoSub').textContent = `${r.assigned ? 'Назначен' : 'Предложен'} маршрут ${r.agent ? r.agent.name + ' · ' : ''}${r.nodes.map(id => NODES[id].short).join(' → ')} · по проездам ${OTO.GEO.fmtM(p.distanceM)}`;
        }
      } else $g('geoSub').textContent = 'Стоянки схемы Р01–Р06 ⇄ зоны обслуживания мс-01…мс-06 · маршрут по реальным проездам';
    }
    if (!(state.automatedTransport && state.ticketStatus === 'enroute')) { if (trap) { map.removeLayer(trap); trap = null; } }
  }
  // обёртки исходных функций (сами функции не изменяются)
  const _renderMap = window.renderMap;
  if (typeof _renderMap === 'function') window.renderMap = function () { const r = _renderMap.apply(this, arguments); try { geoRender(); } catch (e) { console.warn('geo', e); } return r; };
  let trap = null, trapRaf = null;
  const _anim = window.animateTransportSegment;
  if (typeof _anim === 'function') window.animateTransportSegment = function (fromId, toId, duration) {
    const r = _anim.apply(this, arguments);
    try {
      const p = roadPath([fromId, toId]); if (!p || p.pts.length < 2) return r;
      const xy = p.pts.map(q => proj.toXY({ lat: q[0], lon: q[1] })), cum = [0]; for (let i = 1; i < xy.length; i++) cum.push(cum[i - 1] + Math.hypot(xy[i].x - xy[i - 1].x, xy[i].y - xy[i - 1].y));
      const len = cum[cum.length - 1] || 1, t0 = performance.now();
      if (!trap) trap = L.marker(p.pts[0], { pane: 'geo-agents', icon: div('geo-trap', '<b>ТРАП</b>', [44, 20]), title: 'Автоматизированный трап' }).addTo(map);
      if (trapRaf) cancelAnimationFrame(trapRaf);
      const step = ts => {
        if (!state.automatedTransport || state.ticketStatus !== 'enroute') { trapRaf = null; return; }
        const k = Math.min(1, (ts - t0) / duration), e = k * k * (3 - 2 * k), s = e * len; let i = 1; while (i < cum.length - 1 && cum[i] < s) i++;
        const a = xy[i - 1], b = xy[i], seg = cum[i] - cum[i - 1] || 1, t = (s - cum[i - 1]) / seg, ll = proj.toLL({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });
        trap.setLatLng([ll.lat, ll.lon]); if (follow === 'trap') map.panTo([ll.lat, ll.lon], { animate: false });
        if (k < 1) trapRaf = requestAnimationFrame(step); else trapRaf = null;
      };
      trapRaf = requestAnimationFrame(step);
    } catch (e) { console.warn('geo trap', e); }
    return r;
  };

  // ---------- GPS ----------
  let watch = null, fix = null, follow = false, gpsMarker = null, gpsCircle = null, firstFix = true;
  const btnState = () => { const b = $g('geoFollow'); b.classList.toggle('on', watch !== null); b.classList.toggle('follow', !!follow && watch !== null); b.textContent = watch === null ? '⌖ GPS' : follow ? '⌖ Следую' : '⌖ К себе'; };
  map.on('dragstart', () => { if (follow) { follow = false; btnState(); } });
  function nearestSchemeNode(ll) { let best = null; const q = proj.toXY(ll); Object.entries(GEO_NODE).forEach(([id, g]) => { const p = proj.toXY(g); const d = Math.hypot(p.x - q.x, p.y - q.y); if (!best || d < best.d) best = { id, d }; }); return best; }
  function onFix(p) {
    const c = p.coords; fix = { lat: c.latitude, lon: c.longitude, acc: c.accuracy || 0, ts: p.timestamp, speed: c.speed, heading: c.heading };
    const ll = [fix.lat, fix.lon];
    if (!gpsMarker) { gpsCircle = L.circle(ll, { pane: 'geo-gps', radius: fix.acc, color: '#38bdf8', weight: 1, fillOpacity: .12, interactive: false }).addTo(lyr.gps); gpsMarker = L.marker(ll, { pane: 'geo-gps', icon: div('geo-me', '', [18, 18]), title: 'Моё положение' }).addTo(lyr.gps); }
    else { gpsMarker.setLatLng(ll); gpsCircle.setLatLng(ll); gpsCircle.setRadius(fix.acc); }
    if (follow || firstFix) { if (firstFix) map.setView(ll, Math.max(map.getZoom(), 17)); else map.panTo(ll); }
    firstFix = false;
    const near = OTO.GEO.nearestStand(PACK, fix), nn = nearestSchemeNode(fix);
    let t = `GPS: ${fix.lat.toFixed(6)}, ${fix.lon.toFixed(6)} · ±${Math.round(fix.acc)} м · `;
    t += near && near.inside ? `в зоне ${near.stand.geoName}` : near && near.d < 3000 ? `до ${near.stand.geoName} ${OTO.GEO.fmtM(near.d)}` : `вне полигона (${OTO.GEO.fmtM(near ? near.d : 0)})`;
    // привязка вошедшего сотрудника к узлу схемы
    let emp = null; try { emp = typeof authenticatedEmployee !== 'undefined' ? authenticatedEmployee : null; } catch (e) { /* */ }
    const ag = emp && AGENTS.find(a => a.id === emp.id);
    if (ag) {
      const busyMove = state.assignment && state.assignment.agentId === ag.id && ['enroute'].includes(state.ticketStatus);
      if (nn && nn.d <= Math.max(80, Math.min(150, fix.acc)) && !busyMove) {
        if (ag.node !== nn.id) { ag.node = nn.id; ag.gpsLive = true; if (typeof addLog === 'function') addLog(`${ag.name}: положение по GPS привязано к узлу «${NODES[nn.id].short}».`); if (typeof renderAll === 'function') renderAll(); }
        t += ` · ${ag.name} → ${NODES[nn.id].short}`;
      } else t += ` · ${ag.name}: ближайший узел схемы ${NODES[nn.id].short} в ${OTO.GEO.fmtM(nn.d)}`;
    }
    $g('geoStatus').textContent = t;
    sendLive();
  }
  function startGps(andFollow) {
    if (watch !== null) { follow = andFollow || follow; btnState(); if (fix && follow) map.panTo([fix.lat, fix.lon]); return; }
    if (!navigator.geolocation) { $g('geoStatus').textContent = 'Этот браузер не поддерживает геолокацию.'; return; }
    if (window.isSecureContext === false) $g('geoStatus').textContent = 'GPS доступен только по HTTPS или localhost.';
    else $g('geoStatus').textContent = 'Запрашиваем местоположение…';
    follow = !!andFollow; firstFix = true;
    watch = navigator.geolocation.watchPosition(onFix, err => { $g('geoStatus').textContent = ({ 1: 'Доступ к местоположению запрещён. Разрешите геолокацию в настройках браузера.', 2: 'Не удалось определить положение. Проверьте GPS.', 3: 'Время ожидания геолокации истекло.' })[err.code] || 'GPS: ошибка'; }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 30000 });
    btnState();
  }
  function stopGps() { if (watch !== null) navigator.geolocation.clearWatch(watch); watch = null; follow = false; btnState(); $g('geoStatus').textContent = 'GPS-слежение остановлено.'; }
  $g('geoFollow').onclick = () => { if (watch === null) startGps(true); else if (!follow) { follow = true; btnState(); if (fix) map.setView([fix.lat, fix.lon], Math.max(map.getZoom(), 17)); } else stopGps(); };
  const loc = document.getElementById('gpsLocate'); if (loc) loc.addEventListener('click', () => startGps(true)); // дополнительный обработчик к исходному

  // ---------- коллеги онлайн: обмен GPS-позициями через сервер приложения (/ws/gps) ----------
  let ws = null, wsTimer = null, lastSent = 0; const live = {};
  function wsUrl() { try { if (location.protocol === 'http:' || location.protocol === 'https:') return (location.protocol === 'https:' ? 'wss:' : 'ws:') + '//' + location.host + '/ws/gps'; } catch (e) { /* */ } return null; }
  function connect() {
    const u = wsUrl(); if (!u || typeof WebSocket === 'undefined') return;
    try { ws = new WebSocket(u); } catch (e) { return; }
    ws.onmessage = ev => { try { const m = JSON.parse(ev.data); (m.type === 'snapshot' ? m.items : [m]).forEach(showLive); } catch (e) { /* */ } };
    ws.onclose = () => { ws = null; clearTimeout(wsTimer); wsTimer = setTimeout(connect, 6000); };
  }
  function me() { let emp = null; try { emp = typeof authenticatedEmployee !== 'undefined' ? authenticatedEmployee : null; } catch (e) { /* */ } return emp; }
  const clientId = Math.random().toString(36).slice(2, 10);
  function sendLive() {
    if (!ws || ws.readyState !== 1 || !fix || Date.now() - lastSent < 2000) return; lastSent = Date.now(); const e = me();
    ws.send(JSON.stringify({ type: 'gps', client: clientId, id: e ? e.id : 'guest-' + clientId, name: e ? e.name : 'Гость', lat: fix.lat, lon: fix.lon, acc: fix.acc, ts: Date.now() }));
  }
  function showLive(m) {
    if (!m || m.type !== 'gps' || m.client === clientId || typeof m.lat !== 'number') return;
    let x = live[m.client]; const ll = [m.lat, m.lon];
    if (!x) { x = live[m.client] = { mk: L.marker(ll, { pane: 'geo-gps', icon: div('geo-live', esc2((m.name || '?').split(' ').map(s => s[0]).join('').slice(0, 2)), [22, 22]) }).addTo(lyr.live) }; }
    x.mk.setLatLng(ll); x.mk.bindTooltip(`${esc2(m.name || m.id)} · GPS ±${Math.round(m.acc || 0)} м · ${new Date(m.ts).toLocaleTimeString('ru-RU')}`); x.t = Date.now();
  }
  setInterval(() => { Object.entries(live).forEach(([k, x]) => { if (Date.now() - x.t > 120000) { lyr.live.removeLayer(x.mk); delete live[k]; } }); }, 30000);
  connect();

  // первичная отрисовка и подстройка размеров
  geoRender();
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => map.invalidateSize()).observe($g('geoMap'));
})();
