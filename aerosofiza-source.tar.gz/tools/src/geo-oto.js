/* ===== src/client/geo-basemap.js ===== */
/* OTO client · Геоподложка и GPS для карты (дополнение, код OtoMap не переписывается).
   Под прозрачным SVG карты ОТО кладётся карта Leaflet (тайлы OSM / CARTO / Esri), которая повторяет
   текущий вид SVG (центр и масштаб): SVG по-прежнему рисует пакет локации, подбор, маршруты и динамику,
   а подложка показывает реальную местность. Кнопка «⌖» — слежение за GPS устройства (watchPosition). */
(function (root) {
  'use strict';
  const OTO = root.OTO = root.OTO || {};
  if (typeof document === 'undefined' || !OTO.OtoMap) return;
  // однократно: локальное хранилище встроенного сервера переводится на пакет VDNH-GEO (геоданные)
  try { if (localStorage.getItem('oto-geo-v') !== '1') { localStorage.removeItem('oto-store-v1'); localStorage.setItem('oto-geo-v', '1'); } } catch (e) { /* */ }
  const U = OTO.UI || {}, toast = (t, k, ms) => { try { U.toast ? U.toast(t, k, ms) : console.log(t); } catch (e) { /* */ } };
  const NS = 'http://www.w3.org/2000/svg';
  const BASEMAPS = {
    dark: { name: 'Подложка: тёмная (OpenStreetMap)', url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', opt: { maxNativeZoom: 19, className: 'tiles-dark', attribution: '© участники OpenStreetMap' } },
    osm: { name: 'Подложка: OpenStreetMap', url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', opt: { maxNativeZoom: 19, attribution: '© участники OpenStreetMap' } },
    sat: { name: 'Подложка: спутник (Esri)', url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', opt: { maxNativeZoom: 19, attribution: 'Esri, Maxar, Earthstar Geographics' } },
    none: { name: 'Без подложки (только схема)' }
  };
  const ORDER = ['dark', 'osm', 'sat', 'none'];
  const LS = 'oto-basemap';
  let pref = 'dark'; try { const v = localStorage.getItem(LS); if (BASEMAPS[v]) pref = v; } catch (e) { /* */ }
  const all = new Set();
  const fmtM = m => m >= 1000 ? (m / 1000).toFixed(1).replace('.', ',') + ' км' : Math.round(m) + ' м';
  OTO.GEO = OTO.GEO || {}; OTO.GEO.BASEMAPS = BASEMAPS; OTO.GEO.fmtM = fmtM;

  const P = OTO.OtoMap.prototype, _apply = P._applyView, _setPack = P.setPack;
  P._applyView = function () { _apply.call(this); this._baseInit(); this._baseSync(); };
  P.setPack = function (pack) { _setPack.call(this, pack); this._baseInit(); this._baseSync(); this._gpsDraw(); };

  P._baseInit = function () {
    if (this._base !== undefined) return; this._base = null;
    if (!root.L || !this.host) return;
    const div = document.createElement('div'); div.className = 'oto-basemap'; div.setAttribute('aria-hidden', 'true');
    this.host.classList.add('has-basemap'); this.host.insertBefore(div, this.svg);
    const m = root.L.map(div, { zoomControl: false, attributionControl: true, dragging: false, touchZoom: false, scrollWheelZoom: false, doubleClickZoom: false, boxZoom: false, keyboard: false, tap: false, zoomSnap: 0, zoomAnimation: false, fadeAnimation: false, markerZoomAnimation: false, inertia: false, minZoom: 2, maxZoom: 23 });
    m.attributionControl.setPrefix(false);
    this._base = { div, map: m, layer: null, kind: null, W: 0, H: 0 };
    all.add(this);
    this.gG = document.createElementNS(NS, 'g'); this.gG.setAttribute('class', 'g-gps'); this.svg.appendChild(this.gG);
    this.svg.addEventListener('pointerdown', () => { if (this._gps && this._gps.follow) { this._gps.follow = false; this._gpsBtnState(); } });
    this._baseSet(pref, true);
    this._baseTools();
  };
  P._baseSet = function (kind, silent) {
    const b = this._base; if (!b) return; kind = BASEMAPS[kind] ? kind : 'none';
    if (b.layer) { b.map.removeLayer(b.layer); b.layer = null; }
    const d = BASEMAPS[kind]; b.kind = kind;
    if (d.url) { b.layer = root.L.tileLayer(d.url, Object.assign({ maxZoom: 23, detectRetina: false, keepBuffer: 3, updateWhenIdle: false }, d.opt)); b.layer.addTo(b.map); }
    this.host.classList.toggle('basemap-on', !!d.url); this.host.dataset.basemap = kind;
    if (this._baseBtn) this._baseBtn.title = d.name + ' (нажмите, чтобы сменить)';
    if (!silent) toast(d.name);
    this._baseSync(true);
  };
  P.setBasemap = function (kind) { pref = kind; try { localStorage.setItem(LS, kind); } catch (e) { /* */ } all.forEach(m => { if (m.host && m.host.isConnected) m._baseSet(kind, m !== this); else all.delete(m); }); };
  P._baseSync = function (force) {
    const b = this._base; if (!b || !this.view || !this.proj || b.kind === 'none' && !force) return;
    const W = this.host.clientWidth, H = this.host.clientHeight; if (!W || !H) return;
    if (b.W !== W || b.H !== H) { b.W = W; b.H = H; b.map.invalidateSize({ pan: false }); }
    const v = this.view, s = Math.max(v.w / W, v.h / H), cx = v.x + v.w / 2, cy = v.y + v.h / 2;
    const c = this.proj.toLL({ x: cx, y: -cy }), c2 = this.proj.toLL({ x: cx + s * 256, y: -cy });
    const degPx = (c2.lon - c.lon) / 256; if (!(degPx > 0) || !isFinite(c.lat)) return;
    const z = Math.max(2, Math.min(23, Math.log2(360 / (256 * degPx))));
    b.map.setView([c.lat, c.lon], z, { animate: false, reset: false });
  };
  P._baseTools = function () {
    const wrap = this.host.closest && this.host.closest('.oto-map-wrap'), tools = wrap && wrap.querySelector('.oto-map-tools'); if (!tools) return;
    const mk = (txt, aria, fn) => { const b = document.createElement('button'); b.type = 'button'; b.textContent = txt; b.setAttribute('aria-label', aria); b.title = aria; b.dataset.geo = '1'; b.onclick = e => { e.preventDefault(); fn(b); }; tools.appendChild(b); return b; };
    this._baseBtn = mk('◧', 'Сменить подложку', () => { const i = ORDER.indexOf(this._base.kind); this.setBasemap(ORDER[(i + 1) % ORDER.length]); });
    this._baseBtn.title = BASEMAPS[this._base.kind].name + ' (нажмите, чтобы сменить)';
    if (!tools.querySelector('[data-z=me]')) this._gpsBtn = mk('⌖', 'GPS: показать моё положение и следовать', () => this.gpsToggle());
    this._info = document.createElement('div'); this._info.className = 'oto-gps-info oto-hide'; this._info.setAttribute('role', 'status'); wrap.appendChild(this._info);
  };
  // ---------- GPS устройства ----------
  P.gpsToggle = function () {
    const g = this._gps;
    if (g && g.watch != null && !g.follow) { g.follow = true; if (g.fix) this.focus(g.fix, Math.max(this.view.w, 260)); this._gpsBtnState(); return; }
    if (g && g.watch != null) { navigator.geolocation.clearWatch(g.watch); this._gps = null; this._gpsDraw(); this._gpsBtnState(); this._info && this._info.classList.add('oto-hide'); toast('GPS-слежение выключено'); return; }
    if (!navigator.geolocation) { toast('Геолокация в этом браузере недоступна', 'err'); return; }
    if (root.isSecureContext === false) toast('Браузер разрешает GPS только по HTTPS (или localhost)', 'err', 5000);
    this._gps = { watch: null, fix: null, follow: true, first: true };
    this._gps.watch = navigator.geolocation.watchPosition(p => this._gpsFix(p), err => { toast('GPS: ' + (err.code === 1 ? 'доступ запрещён — разрешите геолокацию для сайта' : err.message), 'err', 4000); }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 30000 });
    this._gpsBtnState(); toast('Запрашиваю геопозицию устройства…');
  };
  P._gpsBtnState = function () { const b = this._gpsBtn; if (!b) return; const g = this._gps; b.classList.toggle('on', !!g); b.classList.toggle('follow', !!(g && g.follow)); b.title = !g ? 'GPS: показать моё положение и следовать' : g.follow ? 'GPS: слежение включено (нажмите, чтобы выключить)' : 'GPS: вернуться к моему положению'; };
  P._gpsFix = function (p) {
    const g = this._gps; if (!g) return; const c = p.coords;
    g.fix = { lat: c.latitude, lon: c.longitude, acc: c.accuracy || 0, heading: c.heading, speed: c.speed, ts: p.timestamp };
    OTO.GEO.lastFix = g.fix;
    if (g.follow && this.view) { if (g.first) this.focus(g.fix, Math.max(260, Math.min(1500, g.fix.acc * 6))); else this.focus(g.fix, this.view.w); }
    g.first = false; this._gpsDraw(); this._gpsInfo(); this._gpsBtnState();
  };
  P._gpsDraw = function () {
    if (!this.gG || !this.proj) return; this.gG.innerHTML = ''; const g = this._gps; if (!g || !g.fix) return;
    const [x, y] = this.xy(g.fix);
    if (g.fix.acc) this.el('circle', { cx: x, cy: y, r: g.fix.acc, class: 'oto-gps-acc' }, this.gG);
    const gg = this.el('g', { style: this.tf(x, y), class: 'oto-gps-me' }, this.gG);
    if (g.fix.heading != null && !isNaN(g.fix.heading) && (g.fix.speed || 0) > 0.5) this.el('path', { d: 'M0 -19 L6 -9 L-6 -9 Z', class: 'gps-dir', transform: `rotate(${g.fix.heading})` }, gg);
    this.el('circle', { r: 11, class: 'gps-halo' }, gg); this.el('circle', { r: 6.5, class: 'gps-dot' }, gg);
    this.el('text', { class: 'oto-lbl', y: 22 }, gg, 'Я');
  };
  P._gpsInfo = function () {
    const g = this._gps, el = this._info; if (!el || !g || !g.fix || !this.pack) return;
    const near = OTO.GEO.nearestStand(this.pack, g.fix);
    let t = `GPS ±${Math.round(g.fix.acc || 0)} м · `;
    if (near && near.inside) t += `в зоне <b>${near.stand.geoName || near.stand.name}</b>`;
    else if (near && near.d < 3000) t += `до ${near.stand.geoName || near.stand.name}: <b>${fmtM(near.d)}</b>`;
    else t += `вне учебного полигона${near ? ' (' + fmtM(near.d) + ')' : ''}`;
    el.innerHTML = t; el.classList.remove('oto-hide');
  };
  /** Ближайшая стоянка (по контуру зоны обслуживания из геоданных или по точке стоянки). */
  OTO.GEO.nearestStand = function (pack, ll) {
    if (!pack || !pack.stands || !pack.stands.length) return null; const pr = OTO.Projector(pack.origin), q = pr.toXY(ll); let best = null;
    for (const s of pack.stands) {
      let inside = false; if (s.polygon && s.polygon.length > 2) inside = OTO.pointInPoly(q, s.polygon.map(p => pr.toXY({ lat: p[0], lon: p[1] })));
      const sp = pr.toXY(s), d = inside ? 0 : Math.hypot(sp.x - q.x, sp.y - q.y);
      if (!best || d < best.d) best = { stand: s, d, inside };
    }
    return best;
  };
  // подложка повторяет вид при изменении размеров окна/поворота телефона
  if (typeof window !== 'undefined') window.addEventListener('resize', () => all.forEach(m => { if (m.host && m.host.isConnected) m._baseSync(true); }));
})(typeof globalThis !== 'undefined' ? globalThis : this);
